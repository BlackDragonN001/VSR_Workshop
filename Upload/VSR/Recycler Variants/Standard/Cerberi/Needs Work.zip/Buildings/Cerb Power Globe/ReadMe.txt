POWER GLOBE / GENERATOR

Config names : pgorbit (the 'electrons')
               pgfield
               pgfield2

- Place all three ABOVE the ground (higher than a guntower, I'd say), and in exactly the SAME PLACE.
- pgorbit and pgfield should be set to team 2, pgfield2 to team 3

Notes: This is one of my favourites, because for once the effect of 'spinning electrons' is real - they
are actually held in orbit by the magnetic field, and if you destroy it, the 'electrons' will fly off
in all directions. This was intended as some kind of power generator - after destroying the field, the
player must take care of the generator itself, which isn't easy since the now free 'energy points' are
quite dangerous.
The field and generator can only be destroyed using mortars, from their damage blast - not directly!
Mbikes work fine - I suggest the player use MDM mortars, and manually detonate them. Try this: fire
4 MDMs in such a way that they get caught inside the field (aim slightly underneath the globe), and 
detonate them all at once!
 



