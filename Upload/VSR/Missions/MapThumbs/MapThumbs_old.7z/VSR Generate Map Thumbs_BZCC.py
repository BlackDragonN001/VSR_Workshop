#!/usr/bin/python

maplist_file = "./VSR Maps.txt"

import re
import math

# Stuff involving the creation of CFG controls.
shellmap_name = "%s_vsrthmb.d"
cfg_file = "VSR_Shellmaps.cfg"
cfg_name = "Pg%d"
cfg_tilex = 10
cfg_tiley = 6

# Order of map type.
map_type_order = ("ST", "DM", "FFA", "CTF", "MPI")

# Map type abbrev to full map type name.
typeName = {
"VSR":"Strategy",
"VSR FFA":"Free for All",
"VSR DM":"Deathmatch",
"VSR CTF":"Capture the Flag",
"VSR MPI":"Multiplayer Instant"}

# Simplifies referencing map information and sorting.
sort_by = "size"
class VSRMap:
	def __init__(self, fname, mapStr, loose, respawning_loose, size):
		split = mapStr.split(": ")
		self.type = split[0].upper()
		if not self.type in typeName:
			self.isValid = False
			print("! - Invalid map: %s" % mapStr)
		else:
			self.name = split[1]

		self.fname = fname
		self.size = size
		self.loose = loose
		self.respawning_loose = respawning_loose
	def __str__(self):
		return "%s, %s, %s, size=%d, loose=%d, respawningLoose=%d, VSR=%d, val=%d" % (self.fname, self.type, self.name, self.size, self.loose, self.respawning_loose, self.isVSR, self.isValid)
	def __lt__(self, other):
		if sort_by == "name":
			return self.name < other.name
		if sort_by == "size":
			return self.size < other.size
		if sort_by == "scrap":
			return self.loose+self.respawning_loose > other.loose+other.respawning_loose

mapDict = {}
mapList = {"ST":[], "FFA":[], "DM":[], "CTF":[], "MPI":[]}
reMapItem = re.compile(r"([^ ]+)\.bzn \(([^\)]+)\) \[(\d+)\] \[(\d+)\] \[(\d+)\]")
reComment = re.compile(r"\s*//")
for mapListFile in (maplist_file,):
	fl = open(mapListFile, "r")
	for ln in fl:
		if not re.match(reComment, ln):
			match = re.match(reMapItem, ln)
			if match:
				map = VSRMap(match.group(1), match.group(2), int(match.group(3)), int(match.group(4)), int(match.group(5)))
				mapDict[match.group(1)] = map
				mapList[map.type] += [map]
	fl.close()

def fl_add_header(page, fl, typeName, maxPage):
	thisPage = (typeName.upper()+"-"+cfg_name) % (page)
	
	# Next/Prev
	nextPage = (typeName+"-"+cfg_name) % (page+1)
	prevPage = (typeName+"-"+cfg_name) % (page-1)
	
	# Button
	buttonStr = ("CreateControl(\"%s\",\"BUTTON\")\n"+
	"{\n"+
	"ColorGroup(\"MAGENTA\");\n"+
	"Geom(\"RIGHT\",\"TOP\");\n"+
	"Pos(%d,9);\n"+
	"Size(32,32);\n"+
	"CreateControl(\"ICO\",\"STATIC\")\n"+
	"{\n"+
	"ColorGroup(\"WHITE\");\n"+
	"Geom(\"HCENTER\",\"VCENTER\");\n"+
	"Pos(0,0);\n"+
	"Size(32,32);\n"+
	"Image(\"%s.d\",0,0);\n"+
	"Style(\"INERT\",\"OUTLINE\");\n"+
	"}\n"+
	"BorderSize(2);\nBevelSize(2);\n"+
	"Style(%s);\n"+
	"Cursor(\"Highlight\");\n"+
	"NotifyParent(\"Button::Press\",\"%s\");\n"+
	"}\n"+
	"OnEvent(\"%s\")\n"+
	"{\n"+
	"%s\n"+
	"}\n")
	
	# Static Icon
	iconStr = ("CreateControl(\"ICO\",\"STATIC\")\n"+
	"{\n"+
	"ColorGroup(\"WHITE\");\n"+
	"Geom(\"RIGHT\",\"TOP\");\n"+
	"Pos(%d,9);\n"+
	"Size(32,32);\n"+
	"Image(\"%s.d\",0,0);\n"+
	"Style(\"INERT\",\"OUTLINE\");\n"+
	"}\n")
	
	btn_close = buttonStr % ("Close", -6, "vsrmplst_close", "\"ROLLOVER\",\"OUTLINE\",\"BLINK\"", "CLS", "CLS", ("DeActivate(\"|%s\");" % thisPage))
	if page+1 < maxPage:
		btn_next = buttonStr % ("Next", -60, "vsrmplst_next", "\"ROLLOVER\",\"OUTLINE\"", "NXT", "NXT", ("DeActivate(\"|%s\");\nActivate(\"|%s\");" % (thisPage, nextPage)))
	else:
		btn_next = ""
	if page > 0:
		btn_prev = buttonStr % ("Prev", -100, "vsrmplst_prev", "\"ROLLOVER\",\"OUTLINE\"", "PRV", "PRV", ("DeActivate(\"|%s\");\nActivate(\"|%s\");" % (thisPage, prevPage)))
	else:
		btn_prev = ""
	
	if typeName.lower() != "name":
		btn_name = buttonStr % ("Name", -260, "vsrmplst_alphabet", "\"ROLLOVER\",\"OUTLINE\"", "NAME", "NAME", ("DeActivate(\"|%s\");\nActivate(\"|%s\");" % (thisPage, ("NAME-"+cfg_name) % (page))))
	else:
		btn_name = iconStr % (-260, "vsrmplst_alphabet")
	
	if typeName.lower() != "size":
		btn_size = buttonStr % ("Size", -220, "vsrmplst_distance", "\"ROLLOVER\",\"OUTLINE\"", "SIZE", "SIZE", ("DeActivate(\"|%s\");\nActivate(\"|%s\");" % (thisPage, ("SIZE-"+cfg_name) % (page))))
	else:
		btn_size = iconStr % (-220, "vsrmplst_distance")
	
	if typeName.lower() != "scrap":
		btn_scrap = buttonStr % ("Scrap", -180, "vsrmplst_scrap", "\"ROLLOVER\",\"OUTLINE\"", "SCRAP", "SCRAP", ("DeActivate(\"|%s\");\nActivate(\"|%s\");" % (thisPage, ("SCRAP-"+cfg_name) % (page))))
	else:
		btn_scrap = iconStr % (-180, "vsrmplst_scrap")
	
	# Write
	fl.write(
	("CreateControl(\"%s\",\"WINDOW\")\n{\n" % thisPage)+
	"Geom(\"PARENTWIDTH\",\"PARENTHEIGHT\");\n"+
	"Style(\"OUTLINE\",\"TRANSPARENT\");\n"+
	"CreateControl(\"MAIN_WINDOW\",\"STATIC\")\n{\n"+
	"Geom(\"HCENTER\",\"VCENTER\");\n"+
	"ColorGroup(\"DEFAULT\");\n"+
	"Pos(0,0);\nSize(640,480);\n"+
	"BorderSize(5);\nBevelSize(10);\n"
	"TabSize(0,0);\nStyle(\"OUTLINE\",\"TABROOT\");\n"+
	"TitleFont(\"TINY\");\n"+
	"CreateControl(\"PAYERS_WINDOW\",\"STATIC\")\n{\n"+
	"Geom(\"LEFT\",\"TOP\");\n"+
	"ColorGroup(\"MAGENTA\");\n"+
	"Pos(15,20);\n"+
	"Size(190,21);\n"+
	"BorderSize(5);\n"+
	"BevelSize(10);\n"+
	"TabSize(60,10);\n"+
	"Title(\"Players\");\n"+
	"Style(\"OUTLINE\",\"TABROOT\");\n"+
	"TitleFont(\"TINY\");\n"+
	"CreateControl(\"Sldr\", \"SLIDER\")\n{\n"+
	"ColorGroup(\"BLACKBLUE\");\n"+
	"Position(5, 5);\n"+
	"Size(100, 9);\n"+
	"BorderSize(3);\n"+
	"BevelSize(3);\n"+
	"Style(\"ROLLOVER\");\n"+
	"Cursor(\"Highlight\");\n"+
	"UseVar(\"network.session.ivar2\");\n"+
	"Range(1, 14);\n}\n"+
	"CreateControl(\"P10\",\"BUTTON\")\n{\n"+
	"ColorGroup(\"BLACKBLUE\");\n"+
	"Geom(\"LEFT\",\"VCENTER\");\n"+
	"Pos(125,0);\n"+
	"Size(19,9);\n"+
	"BorderSize(3);\n"+
	"BevelSize(3);\n"+
	"Style(\"ROLLOVER\",\"RADIO\",\"OUTLINE\");\n"+
	"Cursor(\"Highlight\");\n"+
	"Font(\"TINY\");\n"+
	"Text(\"10\");\n"+
	"UseVar(\"network.session.ivar2\");\n"+
	"Value(10);\n}\n"+
	"CreateControl(\"Edit\",\"EDIT\")\n{\n"+
	"ColorGroup(\"DEFAULT\");\n"+
	"Geometry(\"LEFT\",\"VCENTER\");\n"+
	"Position(160,0);\n"+
	"Size(26,9);\n"+
	"BorderSize(3);\n"+
	"BevelSize(3);\n"+
	"JustifyText(\"CENTER\");\n"+
	"Font(\"TINY\");\n"+
	"Style(\"ROLLOVER\",\"OUTLINE\");\n"+
	"Cursor(\"Highlight\");\n"+
	"UseVar(\"network.session.ivar2\");\n}\n"+
	"}\n"+ # 'Players' End.
	
	"CreateControl(\"SDES\",\"STATIC\")\n"+
	"{\n"+
	"ColorGroup(\"WHITE\");\n"+
	"Geom(\"RIGHT\",\"TOP\");\n"+
	"Pos(-330,5);\n"+
	"Size(110,14);\n"+
	("Text(\"Sorted by %s\");\n" % (typeName[0].upper()+typeName[1::].lower()))+
	"Font(\"TINY\");\n"+
	"Style(\"INERT\",\"OUTLINE\",\"TRANSPARENT\");\n"+
	"}\n"+
	
	"CreateControl(\"PG\",\"STATIC\")\n"+
	"{\n"+
	"ColorGroup(\"WHITE\");\n"+
	"Geom(\"RIGHT\",\"TOP\");\n"+
	"Pos(-330,20);\n"+
	"Size(110,14);\n"+
	("Text(\"Page %d/%d\");\n" % (page+1, maxPage))+
	"Font(\"SMALL\");\n"+
	"Style(\"INERT\",\"OUTLINE\",\"TRANSPARENT\");\n"+
	"}\n"+
	
	btn_name+
	btn_size+
	btn_scrap+
	btn_prev+
	btn_next+
	btn_close
	)

def fl_add_footer(page, fl):
	fl.write(
	"CreateControl(\"CMP\",\"STATIC\")\n{\n"+
	"ColorGroup(\"WHITE\");\n"+
	"Geom(\"LEFT\",\"BOTTOM\");\n"+
	"Pos(5,-5);\n"+
	"Size(110,14);\n"+
	"Text(\"Current Map:\");\n"+
	"Font(\"MEDIUM\");\n"+
	"JustifyText(\"LEFT\");\n"+
	"Style(\"INERT\",\"OUTLINE\",\"TRANSPARENT\");\n}\n"+
	
	"CreateControl(\"M\",\"STATIC\")\n{\n"+
	"ColorGroup(\"WHITE\");\n"+
	"Geom(\"LEFT\",\"BOTTOM\");\n"+
	"Pos(115,-5);\n"+
	"Size(200,14);\n"+
	"UseVar(\"network.session.svar0\");\n"+
	"Font(\"MEDIUM\");\n"+
	"JustifyText(\"LEFT\");\n"+
	"Style(\"INERT\",\"OUTLINE\",\"TRANSPARENT\");\n}\n"+
	
	"CreateControl(\"V\",\"STATIC\")\n{\n"+
	"ColorGroup(\"WHITE\");\n"+
	"Geom(\"RIGHT\",\"BOTTOM\");\n"+
	"Pos(-5,-5);\n"+
	"Size(370,14);\n"+
	"Text(\"Orange labels are non-VSR maps. VSR will still automatically be enabled for all maps.\");\n"+
	"Font(\"TINY\");\n"+
	"JustifyText(\"RIGHT\");\n"+
	"Style(\"INERT\",\"OUTLINE\",\"TRANSPARENT\");\n}\n"+
	
	"}\n}\n\n")

def fl_add_thumb(map, x, y, fl):
	image = shellmap_name % map.fname
	
	if map.isVSR:
		bottomTextCGroup = "VSRMTHMB_LBL_VSR"
		mapCGroup = "VSRMTHMB_MAP_VSR"
	else:
		bottomTextCGroup = "VSRMTHMB_LBL_NONVSR"
		mapCGroup = "VSRMTHMB_MAP_NONVSR"
	
	#~ border = ""
	border = (
	"CreateControl(\"B\",\"STATIC\")\n{\n"+
	("ColorGroup(\"%s\");\n" % bottomTextCGroup)+
	"Size(64, 64);\n"+
	"Image(\"vsrthmb_border.d\");\n"+
	"Style(\"INERT\",\"OUTLINE\");\n}\n")

	if sort_by == "size":
		sizeInfo = (
		"CreateControl(\"x\",\"STATIC\")\n{\n"+
		"ColorGroup(\"VSRMTHMB_SIZE\");\n"+
		"Geom(\"HCENTER\",\"VCENTER\");\n"+
		"Pos(0,-9);\n"+
		"Size(64,16);\n"+
		"BevelSize(1);\n"+
		"Style(\"INERT\",\"OUTLINE\");\n"+
		"Font(\"SMALL\");\n"+
		"JustifyText(\"CENTER\");\n"+
		("Text(\"%dm\");\n}\n" % map.size))
	elif sort_by == "scrap":
		if map.respawning_loose:
			scrap_text = "%d + %d" % (map.loose, map.respawning_loose)
		else:
			scrap_text = "%d" % (map.loose)
		sizeInfo = (
		"CreateControl(\"x\",\"STATIC\")\n{\n"+
		"ColorGroup(\"VSRMTHMB_SCRAP\");\n"+
		"Geom(\"HCENTER\",\"VCENTER\");\n"+
		"Pos(0,-9);\n"+
		"Size(64,16);\n"+
		"BevelSize(1);\n"+
		"Style(\"INERT\",\"OUTLINE\");\n"+
		"Font(\"SMALL\");\n"+
		"JustifyText(\"CENTER\");\n"+
		("Text(\"%s\");\n}\n" % scrap_text))
	else:
		sizeInfo = ""
	
	execInfo = ""
	if not map.isVSR:
		execInfo = "Exec(\"NonVSR_%s.exec\");\n" % map.type
	
	name = map.name
	if len(name) > 12:
		name = name[0:7]+"..."
	
	typeInfo = ""
	if map.type != "ST":
		typeInfo = (
		"CreateControl(\"x\",\"STATIC\")\n{\n"+
		"ColorGroup(\"VSRMTHMB_TYPE\");\n"+
		"Geom(\"HCENTER\",\"VCENTER\");\n"+
		"Pos(0,14);\n"+
		"Size(64,16);\n"+
		"BevelSize(1);\n"+
		"Style(\"INERT\",\"TRANSPARENT\");\n"+
		"Font(\"LARGE\");\n"+
		"JustifyText(\"CENTER\");\n"+
		("Text(\"%s\");\n}\n" % map.type))
	
	fl.write(
	("CreateControl(\"%s\",\"BUTTON\")\n{\n" % map.fname.upper())+
	("ColorGroup(\"%s\");\n" % mapCGroup)+
	"Geom(\"LEFT\",\"TOP\");\n"+
	("Pos(%d,%d);\n" % (x, y))+
	"Size(64,64);\n"+
	("Image(\"%s\",0,0);\n" % image)+
	"Style(\"ROLLOVER\",\"OUTLINE\");\n"+
	"Cursor(\"Highlight\");\n"+
	typeInfo+
	sizeInfo+
	border+
	"CreateControl(\"t\",\"STATIC\")\n{\n"+
	("ColorGroup(\"%s\");\n" % bottomTextCGroup)+
	"Geom(\"HCENTER\",\"BOTTOM\");\n"+
	"Pos(0,0);\n"+
	"Size(64,10);\n"+
	"BevelSize(1);\n"+
	"Style(\"INERT\");\n"+
	"Font(\"TINY\");\n"+
	"JustifyText(\"CENTER\");\n"+
	("Text(\"%s\");\n}\n" % name)+
	("NotifyParent(\"Button::Press\",\"%s\");\n}\n" % map.fname.upper())+
	("OnEvent(\"%s\")\n{\n" % map.fname.upper())+
	("Cmd(\"Network.session.svar0 '%s.bzn'\");%s\n}\n" % (map.fname, execInfo)))

sort_types = ["name", "size", "scrap"]
maxPage = math.ceil(len(mapDict)/60)
fl = open(cfg_file, "w")
fl.write("Exec(\"VSR_Shellmap_colors.cfg\");\n\n")
for sort_type in sort_types:
	print("Sorting type: %s" % sort_type)
	sort_by = sort_type
	x, y, page = 0, 0, 0
	fl_add_header(page, fl, sort_type, maxPage)
	
	#~ print("Page %d" % (page+1))
	for ind, type in enumerate(map_type_order):
		mapList[type].sort()
		
		for map in mapList[type]:
			#~ print("*", end=" ")
			fl_add_thumb(map, x*64, y*64+64, fl)
			
			x += 1
			if x >= cfg_tilex:
				#~ print("")
				x = 0
				y += 1
				if y >= cfg_tiley:
					#~ print("Page %d" % (page+2))
					y = 0
					fl_add_footer(page, fl)
					page += 1
					fl_add_header(page, fl, sort_type, maxPage)
	fl_add_footer(page, fl)
	#~ print("")

fl.close()

