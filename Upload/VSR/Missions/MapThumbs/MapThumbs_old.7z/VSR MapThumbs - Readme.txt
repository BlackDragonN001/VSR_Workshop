Before running 'VSR Generate Map Thumbs.py' you should run 'VSR Get Full Map List.py'.
